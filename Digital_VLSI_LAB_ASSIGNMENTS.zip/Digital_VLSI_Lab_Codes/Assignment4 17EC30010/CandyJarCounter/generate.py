from random import choices
from collections import Counter
nums=[0,1,2]
weights=[.48,.48,.04]
samples=choices(nums,weights,k=10**4)
f=open("input.txt","w+")
for sample in samples:
    f.write(f"{sample}\n")
f.close()
print(Counter(samples))

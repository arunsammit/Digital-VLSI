/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "a(%b) + b(%b)  = carry sum(%b %b)";
static const char *ng1 = "D:/6th sem/Digital VLSI/carry_look_ahead_adder_single/cla_test.v";
static int ng2[] = {0, 0};
static int ng3[] = {128, 0};
static int ng4[] = {1, 0};

void Monitor_53_2(char *);
void Monitor_53_2(char *);


static void Monitor_53_2_Func(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    t1 = (t0 + 1608);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t0 + 1768);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t0 + 1928);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t0 + 1208U);
    t11 = *((char **)t10);
    xsi_vlogfile_write(1, 0, 3, ng0, 5, t0, (char)118, t3, 7, (char)118, t6, 7, (char)118, t9, 1, (char)118, t11, 7);

LAB1:    return;
}

static void Initial_45_0(char *t0)
{
    char *t1;
    char *t2;

LAB0:    xsi_set_current_line(45, ng1);

LAB2:    xsi_set_current_line(47, ng1);
    t1 = ((char*)((ng2)));
    t2 = (t0 + 1608);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 7);
    xsi_set_current_line(48, ng1);
    t1 = ((char*)((ng2)));
    t2 = (t0 + 1768);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 7);
    xsi_set_current_line(49, ng1);
    t1 = ((char*)((ng2)));
    t2 = (t0 + 1928);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 1);

LAB1:    return;
}

static void Initial_52_1(char *t0)
{

LAB0:    xsi_set_current_line(53, ng1);
    Monitor_53_2(t0);

LAB1:    return;
}

static void Always_54_3(char *t0)
{
    char t7[8];
    char t8[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;

LAB0:    t1 = (t0 + 3504U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(54, ng1);
    t2 = (t0 + 4072);
    *((int *)t2) = 1;
    t3 = (t0 + 3536);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(55, ng1);

LAB5:    xsi_set_current_line(58, ng1);
    xsi_set_current_line(58, ng1);
    t4 = ((char*)((ng2)));
    t5 = (t0 + 2088);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);

LAB6:    t2 = (t0 + 2088);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng3)));
    t6 = ((char*)((ng3)));
    memset(t7, 0, 8);
    xsi_vlog_signed_multiply(t7, 32, t5, 32, t6, 32);
    memset(t8, 0, 8);
    xsi_vlog_signed_less(t8, 32, t4, 32, t7, 32);
    t9 = (t8 + 4);
    t10 = *((unsigned int *)t9);
    t11 = (~(t10));
    t12 = *((unsigned int *)t8);
    t13 = (t12 & t11);
    t14 = (t13 != 0);
    if (t14 > 0)
        goto LAB7;

LAB8:    xsi_set_current_line(62, ng1);
    t2 = (t0 + 3312);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB10;
    goto LAB1;

LAB7:    xsi_set_current_line(59, ng1);
    t15 = (t0 + 3312);
    xsi_process_wait(t15, 1000LL);
    *((char **)t1) = &&LAB9;
    goto LAB1;

LAB9:    xsi_set_current_line(59, ng1);
    t16 = (t0 + 2088);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    t19 = (t0 + 1768);
    xsi_vlogvar_assign_value(t19, t18, 0, 0, 7);
    t20 = (t0 + 1608);
    xsi_vlogvar_assign_value(t20, t18, 7, 0, 7);
    xsi_set_current_line(58, ng1);
    t2 = (t0 + 2088);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t7, 0, 8);
    xsi_vlog_signed_add(t7, 32, t4, 32, t5, 32);
    t6 = (t0 + 2088);
    xsi_vlogvar_assign_value(t6, t7, 0, 0, 32);
    goto LAB6;

LAB10:    xsi_set_current_line(62, ng1);
    xsi_vlog_stop(1);
    goto LAB2;

}

void Monitor_53_2(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 3560);
    t2 = (t0 + 4088);
    xsi_vlogfile_monitor((void *)Monitor_53_2_Func, t1, t2);

LAB1:    return;
}


extern void work_m_00000000002536973212_1095221129_init()
{
	static char *pe[] = {(void *)Initial_45_0,(void *)Initial_52_1,(void *)Always_54_3,(void *)Monitor_53_2};
	xsi_register_didat("work_m_00000000002536973212_1095221129", "isim/cla_test_isim_beh.exe.sim/work/m_00000000002536973212_1095221129.didat");
	xsi_register_executes(pe);
}
